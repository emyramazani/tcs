import { NgModule } from '@angular/core';
import { RouterModule,Routes} from '@angular/router'
import { AdminComponent} from '../components/admin/admin.component'
import { AdminitemComponent } from '../components/adminitem/adminitem.component'
import { UserComponent } from '../components/user/user.component';
import { LoginComponent } from '../components/login/login.component';
import { RegisterComponent } from '../components/register/register.component'

const appRoutes:Routes=[
  { path:'admin', component:AdminComponent},
  { path: 'adminitem', component: AdminitemComponent },
  { path: 'user', component:UserComponent},
  { path: 'login', component:LoginComponent},
  { path: 'register', component:RegisterComponent} , 
  { path: '', component:UserComponent},
  /*{ path: 'user', component:UserComponent , 
    children: [
      //{ path: 'register', redirectTo: './user/register',pathMatch: 'full'},
      { path: 'register', component: RegisterComponent}
    ]
  }*/

]


@NgModule({
  imports: [RouterModule.forRoot(appRoutes) ],
  exports: [RouterModule ]
})
export class AppRoutingModule { }
