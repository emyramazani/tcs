
export interface ILogin{
    _id?: string;
    username: string;
    password: string;
}

export class Login implements ILogin{
    constructor(
        public username:string,
        public password:string,
        public _id?: string
    ){
        this._id=_id? _id:null;
        this.username=username;
        this.password= password;
    }
}