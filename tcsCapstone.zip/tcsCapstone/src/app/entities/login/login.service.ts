import { Injectable } from '@angular/core';
//import { Http } from '@angular/http';
import {HttpClient} from '@angular/common/http'
import { ILogin, Login } from './login.model';
import { IRegister, Register} from './register.model'
import { IAdmin, Admin} from './admin.model'
import { IAdminitem, Adminitem} from './adminitem.model'
import { Observable } from 'rxjs';


@Injectable({
    providedIn: 'root'
})
export class LoginService {
    private loginUrl = '/api/user';
    private registerUrl = '/api/register';
    private adminUrl = '/api/admin';
    private adminItemUrl = '/api/adminitem';

    constructor(private http: HttpClient) { }

    //get data from db
    getLogin(login: Login){
        return this.http.get(this.loginUrl)
        .subscribe((res)=>{
            console.log(res)
        })
    }
     //Add User
    AddUser(admin: Admin){
        return this.http.post(this.adminUrl,admin).subscribe(data => {
        })
    }
    //Add Item
    AdminAdditem(adminItem: Adminitem){
        return this.http.post(this.adminItemUrl,adminItem).subscribe(data => {
        })
    }
    /*
    //Add User
    AddUser1(admin: Admin): Promise<IAdmin>{
        return this.http.post(this.adminUrl,admin) // post to insert
        .toPromise()
        .then(response => response.json())
        .catch(this.error);
    }
    */

    //Update User
    UpdateUser(admin: Admin){
        return this.http.put(this.adminUrl,admin) // post to insert
        .subscribe(data =>{  //subscribe allow you use the data that you received
            console.log(data)
        })
        console.log('user is added to db',admin)
    }

     //Update User
     AdminUpdateitem(admin: Adminitem){
        return this.http.put(this.adminItemUrl,admin) // post to insert
        .subscribe(data =>{  //subscribe allow you use the data that you received
            console.log(data)
        })
        console.log('user is added to db',admin)
    }

     //delete User

     DeleteUser(email: any){
        this.http.delete(`${this.adminUrl}/${email}`)
        
    }



    // Create User
    createUser(register: Register){
        
       return this.http.post(this.registerUrl,register) // post to insert
        .subscribe(data =>{  //subscribe allow you use the data that you received
            console.log(data)
        })
        console.log('user is added to db',register)
    }


    // Delete a product
    delete(id: string): Promise<any> {
        return this.http.delete(`${this.loginUrl}/${id}`)
            .toPromise()
            .then(response => response.constructor())
            .catch(this.error);
    }

    // Error handling
    private error(error: any) {
        let message = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(message);
    }
}
