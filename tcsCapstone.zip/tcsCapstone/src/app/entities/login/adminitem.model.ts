

export interface IAdminitem{
    _id?: string;
    name: string;
    type: string;
    color: string;
    quantity: number;
    price: number

}

export class Adminitem implements IAdminitem{
    constructor(
        public name: string,
        public type: string,
        public color:string,
        public quantity:number,
        public price: number,
        public _id?: string
    ){
        this._id=_id? _id:null;
        this.name= name;
        this.type= type;
        this.color=color;
        this.quantity= quantity;
        this.price= price;
    }
}