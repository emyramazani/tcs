

export interface IAdmin{
    _id?: string;
    firstname: string;
    lastname: string;
    email: string;
    location: string;

}

export class Admin implements IAdmin{
    constructor(
        public firstname: string,
        public email: string,
        public lastname:string,
        public location:string,
        public _id?: string
    ){
        this._id=_id? _id:null;
        this.firstname= name;
        this.email= email;
        this.lastname=lastname;
        this.location= location;
    }
}