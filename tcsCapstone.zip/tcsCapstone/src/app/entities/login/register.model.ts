
export interface IRegister{
    _id?: string;
    name: string;
    email: string;
    username: string;
    password: string;
}

export class Register implements IRegister{
    constructor(
        public name: string,
        public email: string,
        public username:string,
        public password:string,
        public _id?: string
    ){
        this._id=_id? _id:null;
        this.name= name;
        this.email= email;
        this.username=username;
        this.password= password;
    }
}