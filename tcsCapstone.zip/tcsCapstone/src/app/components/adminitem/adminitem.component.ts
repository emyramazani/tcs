import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { LoginService } from 'src/app/entities/login/login.service';
import { IAdminitem, Adminitem } from 'src/app/entities/login/adminitem.model';
import {FormControl, FormGroup, FormBuilder, Validators, ReactiveFormsModule  } from '@angular/forms' 

@Component({
  selector: 'app-adminitem',
  templateUrl: './adminitem.component.html',
  styleUrls: ['./adminitem.component.css']
})
export class AdminitemComponent implements OnInit {

  adminItemForm: FormGroup;
  adminItemFormAdd: FormGroup;
  adminItemFormDelete:FormGroup;
  adminItemFormUpdate:FormGroup;
  
  name: string ='';
  type: string ='';
  color: string='';
  quantity: number= 0;
  price: number=0;
  error: boolean= false;

  radio:FormControl;
 
  @Output() AddItemInfo= new EventEmitter<IAdminitem>();
 
  constructor( protected adminItemService: LoginService, protected formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.initForm();
  }

  onSubmitAddItem() {
    
    const admValue = new Adminitem(this.adminItemFormAdd.value['name'], this.adminItemFormAdd.value['type'],this.adminItemFormAdd.value['color'],this.adminItemFormAdd.value['quantity'], this.adminItemFormAdd.value['price'], null);
    this.adminItemService.AdminAdditem(admValue).add((result: IAdminitem) => {
      if (result === undefined) {
        this.error = true;
      } else {
        this.error = false;
        this.AddItemInfo.emit(result);
      }
    });
  }

  onSubmitItemUpdate(){
    const admValueUpdate = new Adminitem(this.adminItemFormAdd.value['name'], this.adminItemFormAdd.value['type'],this.adminItemFormAdd.value['color'],this.adminItemFormAdd.value['quantity'], this.adminItemFormAdd.value['price'], null);
    this.adminItemService.AdminUpdateitem(admValueUpdate).add((result: IAdminitem) => {
      if (result === undefined) {
        this.error = true;
      } else {
        this.error = false;
        this.AddItemInfo.emit(result);
      }
    });
  }

  onSubmitItemDelete(){
    const admD = new Adminitem(this.adminItemFormAdd.value['name'], this.adminItemFormAdd.value['type'],this.adminItemFormAdd.value['color'],this.adminItemFormAdd.value['quantity'], this.adminItemFormAdd.value['price'], null);
    this.adminItemService.DeleteUser(admD)
  }

  
  private initForm(){
   
   this.adminItemFormAdd=new FormGroup({
    name: new FormControl(this.name, Validators.required),
    type: new FormControl(this.type, Validators.required),
    color: new FormControl(this.color, Validators.required),
    quantity: new FormControl(this.quantity, Validators.required),
    price: new FormControl(this.price, Validators.required),
    //adminRadios: new FormControl(this.changeOption)

  });

  this.adminItemFormDelete=new FormGroup({
    name: new FormControl(this.name, Validators.required),
    type: new FormControl(this.type, Validators.required),
    color: new FormControl(this.color, Validators.required),
    quantity: new FormControl(this.quantity, Validators.required),
    price: new FormControl(this.price, Validators.required),
    //adminRadios: new FormControl(this.changeOption)

  });

  this.adminItemFormUpdate=new FormGroup({
    name: new FormControl(this.name, Validators.required),
    type: new FormControl(this.type, Validators.required),
    color: new FormControl(this.color, Validators.required),
    quantity: new FormControl(this.quantity, Validators.required),
    price: new FormControl(this.price, Validators.required),
    //adminRadios: new FormControl(this.changeOption)

  });
  }
}


