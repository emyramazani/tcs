
import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { LoginService } from 'src/app/entities/login/login.service';
import { IRegister, Register } from 'src/app/entities/login/register.model';
import {FormControl, FormGroup, FormBuilder, Validators, ReactiveFormsModule  } from '@angular/forms' 

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {


  registerForm: FormGroup;
  
  name: string='';
  email: string ='';
  username: string ='';
  password: string ='';

  error: boolean= false;
          //createdProduct            //IProduct
  @Output() createUserinfo= new EventEmitter<IRegister>();

  constructor( protected registerService: LoginService, protected formBuilder: FormBuilder) { }


  ngOnInit(): void {
    this.initForm();
  }

// Manage the submit action and create the new user.
  onSubmit(){
    const register= new Register(this.registerForm.value['name'],this.registerForm.value['email'],this.registerForm.value['username'], this.registerForm.value['password'],null);
    this.registerService.createUser(register).add((result: IRegister) =>{
      if (result === undefined) {
        this.error = true;
      } else {
        this.error = false;
        this.createUserinfo.emit(result);
      }
    });
  }

  hireError(){
    this.error = false;
  }

  private initForm(){
    this.registerForm = new FormGroup({
      name: new FormControl(this.name, Validators.required),
      email: new FormControl(this.email, Validators.required),
      username: new FormControl(this.username, Validators.required),
      password: new FormControl(this.password, Validators.required)
    });
  }

}
