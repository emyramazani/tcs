import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { LoginService } from 'src/app/entities/login/login.service';
import { IAdmin, Admin } from 'src/app/entities/login/admin.model';
import {FormControl, FormGroup, FormBuilder, Validators, ReactiveFormsModule  } from '@angular/forms' 

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  adminItemForm: FormGroup;
  adminItemFormAdd: FormGroup;
  adminItemFormDelete:FormGroup;
  adminItemFormUpdate:FormGroup;
  
  firstname: string ='';
  lastname: string ='';
  email: string='';
  location: string='';
  //adminRadios: boolean;



  error: boolean= false;

 radio:FormControl;

 @Output() AddUserInfo= new EventEmitter<IAdmin>();

 constructor( protected adminService: LoginService, protected formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.initForm();
  }
  
 /* onSubmitAdd(){
    const admin= new Admin(this.adminItemFormAdd.value['firstname'],this.adminItemFormAdd.value['lastname'],this.adminItemFormAdd.value['email'], this.adminItemFormAdd.value['location'],null);
    this.adminService.AddUser(admin).then((result: IAdmin) => {
      if (result === undefined) {
        this.error = true;
      } else {
        this.error = false;
        this.AddUserInfo.emit(result);
      }
    });
  }*/



  onSubmitAdd() {
    
    const adm = new Admin(this.adminItemFormAdd.value['firstname'], this.adminItemFormAdd.value['lastname'],this.adminItemFormAdd.value['email'],this.adminItemFormAdd.value['location'], null);
    this.adminService.AddUser(adm).add((result: IAdmin) => {
      if (result === undefined) {
        this.error = true;
      } else {
        this.error = false;
        this.AddUserInfo.emit(result);
      }
    });
  }

  



  onSubmitUpdate(){

  }

  onSubmitDelete(){
    const admD = new Admin(this.adminItemFormAdd.value['firstname'], this.adminItemFormAdd.value['lastname'],this.adminItemFormAdd.value['email'],this.adminItemFormAdd.value['location'], null);
    this.adminService.DeleteUser(admD)
  }
 
  onSubmitDelete1(id: string) {
    this.adminService.delete(id);
  }

  onSubmit(){
    //const login= new Login(this.loginForm.value['username'], this.loginForm.value['password'],null);
  //  this.loginService.get(login).add(res =>{
   //   console.log(res);
   // })
   console.log('aime');
  }

  //changeOption(e) {
  //  console.log(e.target.value);
  //}



  private initForm(){
    this.adminItemForm = new FormGroup({
      firstname: new FormControl(this.firstname, Validators.required),
      lastname: new FormControl(this.lastname, Validators.required),
      email: new FormControl(this.email, Validators.required),
      location: new FormControl(this.location, Validators.required),
      //adminRadios: new FormControl(this.changeOption)

    });
   this.adminItemFormAdd=new FormGroup({
    firstname: new FormControl(this.firstname, Validators.required),
    lastname: new FormControl(this.lastname, Validators.required),
    email: new FormControl(this.email, Validators.required),
    location: new FormControl(this.location, Validators.required),
    //adminRadios: new FormControl(this.changeOption)

  });

  this.adminItemFormDelete=new FormGroup({
    firstname: new FormControl(this.firstname, Validators.required),
    lastname: new FormControl(this.lastname, Validators.required),
    email: new FormControl(this.email, Validators.required),
    location: new FormControl(this.location, Validators.required),
    //adminRadios: new FormControl(this.changeOption)

  });

  this.adminItemFormUpdate=new FormGroup({
    firstname: new FormControl(this.firstname, Validators.required),
    lastname: new FormControl(this.lastname, Validators.required),
    email: new FormControl(this.email, Validators.required),
    location: new FormControl(this.location, Validators.required),
    //adminRadios: new FormControl(this.changeOption)

  });
  }
}
