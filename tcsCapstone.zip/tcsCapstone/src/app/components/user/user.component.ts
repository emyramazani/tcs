import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { LoginService } from 'src/app/entities/login/login.service';
import { ILogin, Login } from 'src/app/entities/login/login.model';
import {FormControl, FormGroup, FormBuilder, Validators, ReactiveFormsModule  } from '@angular/forms' 



@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  loginForm: FormGroup;
  
  username: string ='';
  password: string ='';

  error: boolean= false;
          //createdProduct            //IProduct
  @Output() loginInfo= new EventEmitter<ILogin>();

  constructor( protected loginService: LoginService, protected formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.initForm();
  }

  onSubmit(){
    const login= new Login(this.loginForm.value['username'], this.loginForm.value['password'],null);
    this.loginService.getLogin(login).add(res =>{
      console.log(res);
    })
  }

  hireError(){
    this.error = false;
  }

  private initForm(){
    this.loginForm = new FormGroup({
      username: new FormControl(this.username, Validators.required),
      password: new FormControl(this.password, Validators.required)
    });
  }

}
