// Use Express
var express = require("express");
// Use body-parser
var bodyParser = require("body-parser");
// Use MongoDB
var mongodb = require("mongodb");
var ObjectID = mongodb.ObjectID;
// The database variable
var database;
// The products collection
var PRODUCTS_COLLECTION = "products";
var PRODUCTS_COLLECTIONitems = "items";
var PRODUCTS_COLLECTIONlogin = "login";
var PRODUCTS_COLLECTIONUserInfo = "UserInfo";
var PRODUCTS_COLLECTIONUserRegister = "UserRegister";
var PRODUCTS_COLLECTIONUserWishList = "UserWishList";
var PRODUCTS_COLLECTIONUserItemCart = "UserItemCart";
var PRODUCTS_COLLECTIONUserItempurchase = "UserItempurchase";


loginUrl = '/api/user';
registerUrl = '/api/register';
adminUrl = '/api/admin';
adminItemUrl = '/api/adminitem';
// Create new instance of the express server
var app = express();

// Define the JSON parser as a default way 
// to consume and produce data through the 
// exposed APIs
app.use(bodyParser.json());

// Create link to Angular build directory
// The `ng build` command will save the result
// under the `dist` folder.
var distDir = __dirname + "/dist/";
app.use(express.static(distDir));

// Local database URI.
const LOCAL_DATABASE = "mongodb+srv://aime:aime123@cluster0.zrz54.mongodb.net/TCSProducts?retryWrites=true&w=majority";
// Local port.
const LOCAL_PORT = 8080;

// Init the server
mongodb.MongoClient.connect(process.env.MONGODB_URI || LOCAL_DATABASE,
    {
        useUnifiedTopology: true,
        useNewUrlParser: true,
    }, function (error, client) {

        // Check if there are any problems with the connection to MongoDB database.
        if (error) {
            console.log(error);
            process.exit(1);
        }

        // Save database object from the callback for reuse.
        database = client.db();
        console.log("Database connection done.");

        // Initialize the app.
        var server = app.listen(process.env.PORT || LOCAL_PORT, function () {
            var port = server.address().port;
            console.log("App now running on port", port);
        });
    });

/*  "/api/status"
 *   GET: Get server status
 *   PS: it's just an example, not mandatory
 */
app.get("/api/status", function (req, res) {
    res.status(200).json({ status: "UP" });
});

/*  "/api/products"
 *  GET: finds all products
 */
app.get("/api/products", function (req, res) {
    database.collection(PRODUCTS_COLLECTION).find({}).toArray(function (error, data) {
        if (error) {
            manageError(res, err.message, "Failed to get contacts.");
        } else {
            res.status(200).json(data);
        }
    });
});

//Login
app.get("/api/user", function (req, res) {
    database.collection(PRODUCTS_COLLECTIONlogin).find({}).toArray(function (error, data) {
        if (error) {
            manageError(res, err.message, "Failed to get contacts.");
        } else {
            res.status(200).json(data);
            
        }
    });
});



/*  "/api/products"
 *   POST: creates a new product
 */
app.post("/api/products", function (req, res) {
    var product = req.body;

    if (!product.name) {
        manageError(res, "Invalid product input", "Name is mandatory.", 400);
    } else if (!product.brand) {
        manageError(res, "Invalid product input", "Brand is mandatory.", 400);
    } else {
        database.collection(PRODUCTS_COLLECTION).insertOne(product, function (err, doc) {
            if (err) {
                manageError(res, err.message, "Failed to create new product.");
            } else {
                res.status(201).json(doc.ops[0]);
            }
        });
    }
});
//create user
app.post("/api/admin", function (req, res) {
    var user = req.body;
    if (!user.name) {
        manageError(res, "Invalid user input", "Name is mandatory.", 400);
    } else {
        database.collection(PRODUCTS_COLLECTIONUserInfo).insertOne(user, function (err, doc) {
            if (err) {
                manageError(res, err.message, "Failed to create new user.");
            } else {
                res.status(201).json(doc.ops[0]);
            }
        });
    }
});
//register user
app.post("/api/register", function (req, res) {
    var user = req.body;
    if (!user.name) {
        manageError(res, "Invalid user input", "Name is mandatory.", 400);
    } else {
        database.collection(PRODUCTS_COLLECTIONUserRegister).insertOne(user, function (err, doc) {
            if (err) {
                manageError(res, err.message, "Failed to create new user.");
            } else {
                res.status(201).json(doc.ops[0]);
            }
        });
    }
});
//create item
app.post("/api/adminitem", function (req, res) {
    var item = req.body;
    if (!user.name) {
        manageError(res, "Invalid item input", "Name is mandatory.", 400);
    } else {
        database.collection(PRODUCTS_COLLECTIONitems).insertOne(item, function (err, doc) {
            if (err) {
                manageError(res, err.message, "Failed to create new item.");
            } else {
                res.status(201).json(doc.ops[0]);
            }
        });
    }
});


//update

// user
app.put("/api/admin", function (req, res) {
    var user = req.body;
    if (!user.name) {
        manageError(res, "Invalid user input", "Name is mandatory.", 400);
    } else {
        database.collection(PRODUCTS_COLLECTIONUserInfo).insertOne(user, function (err, doc) {
            if (err) {
                manageError(res, err.message, "Failed to create new user.");
            } else {
                res.status(201).json(doc.ops[0]);
            }
        });
    }
});

// item
app.put("/api/adminitem", function (req, res) {
    var item = req.body;
    if (!user.name) {
        manageError(res, "Invalid item input", "Name is mandatory.", 400);
    } else {
        database.collection(PRODUCTS_COLLECTIONitems).insertOne(item, function (err, doc) {
            if (err) {
                manageError(res, err.message, "Failed to create new item.");
            } else {
                res.status(201).json(doc.ops[0]);
            }
        });
    }
});


/*  "/api/admin/:email"
 *   DELETE: deletes user by email
 */
app.delete("/api/admin/:email", function (req, res) {
    if (req.params.email.length > 4 || req.params.email.length < 4) {
        manageError(res, "Invalid user email", "Please provide the correct email.", 400);
    } else {
        database.collection(PRODUCTS_COLLECTIONUserInfo).deleteOne({ _id: new ObjectID(req.params.id) }, function (err, result) {
            if (err) {
                manageError(res, err.message, "Failed to delete user.");
            } else {
                res.status(200).json(req.params.id);
            }
        });
    }
});

app.delete("/api/adminItem/:name", function (req, res) {
    if (req.params.name.length > 4 || req.params.name.length < 4) {
        manageError(res, "Invalid the item name", "Please provide the correct name.", 400);
    } else {
        database.collection(PRODUCTS_COLLECTIONUserInfo).deleteOne({ _id: new ObjectID(req.params.id) }, function (err, result) {
            if (err) {
                manageError(res, err.message, "Failed to delete item.");
            } else {
                res.status(200).json(req.params.name);
            }
        });
    }
});
// Errors handler.
function manageError(res, reason, message, code) {
    console.log("Error: " + reason);
    res.status(code || 500).json({ "error": message });
}